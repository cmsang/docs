variable "iso_file" {
  type    = string
  default = ""
}

variable "proxmox_api_url" {
  type    = string
  default = ""
}

variable "proxmox_node" {
  type    = string
  default = ""
}

variable "proxmox_username" {
  type    = string
  default = ""
}

variable "proxmox_token" {
  type      = string
  sensitive = true
  default   = ""
}

variable "ssh_username" {
  type    = string
  default = ""
}

variable "ssh_password" {
  type    = string
  default = ""
}

variable "ssh_timeout" {
  type    = string
  default = ""
}

# Ubuntu Server Noble Numbat
# ---
# Packer Template to create an Ubuntu Server 24.04 LTS (Noble Numbat) on Proxmox

# Resource Definiation for the VM Template

packer {
  required_plugins {
    name = {
      version = "~> 1"
      source  = "github.com/hashicorp/proxmox"
    }
  }
}

source "proxmox-iso" "ubuntu-server-jammy" {

  # Proxmox Connection Settings
  proxmox_url = "${var.proxmox_api_url}"
  username    = "${var.proxmox_username}"
  token       = "${var.proxmox_token}"
  insecure_skip_tls_verify = true

  # VM General Settings
  node                 = "${var.proxmox_node}"
  vm_id                = 8002
  vm_name              = "ubuntu-server-jammy"
  template_description = "ubuntu-server-jammy"
  bios                 = "seabios"
  # VM OS Settings
  # (Option 1) Local ISO File
  # iso_file = "${var.iso_file}"
  # - or -
  # (Option 2) Download ISO
  # iso_url = "https://releases.ubuntu.com/22.04/ubuntu-22.04-live-server-amd64.iso"
  # iso_checksum = "84aeaf7823c8c61baa0ae862d0a06b03409394800000b3235854a6b38eb4856f"
  # unmount_iso      = true
  template_name    = "packer-ubuntu-live-server-24.04"

  boot_iso {
    type             = "scsi"
    iso_file         = "${var.iso_file}"
    unmount          = true
    # iso_checksum = "sha512:33c08e56c83d13007e4a5511b9bf2c4926c4aa12fd5dd56d493c0653aecbab380988c5bf1671dbaea75c582827797d98c4a611f7fb2b131fbde2c677d5258ec9"
  }

  # VM System Settings
  qemu_agent = true

  # VM Hard Disk Settings
  scsi_controller = "virtio-scsi-pci"

  disks {
    cache_mode   = "writeback"
    disk_size    = "64G"
    ssd          = true
    storage_pool = "local-lvm"
    type         = "sata"
  }

  # VM CPU Settings
  cpu_type = "host"
  sockets  = 2
  cores    = 4


  # VM Memory Settings
  memory             = 8192
  ballooning_minimum = 256

  # VM Network Settings
  network_adapters {
    bridge   = "vmbr0"
    firewall = true
    model    = "virtio"
  }

  # VM Cloud-Init Settings
  cloud_init              = true
  cloud_init_storage_pool = "local-lvm"

  # PACKER Boot Commands
  boot_command = [
    "<esc><wait>",
    "e<wait>",
    "<down><down><down><end>",
    "<bs><bs><bs><bs><wait>",
    "autoinstall ds=nocloud-net\\;s=http://{{ .HTTPIP }}:{{ .HTTPPort }}/ ---<wait>",
    "<f10><wait>"
  ]
  boot      = "c"
  boot_wait = "6s"

  # PACKER Autoinstall Settings
  http_directory = "./http"
  # http_bind_address = "{{ .HTTPIP }}"
  # (Optional) Bind IP Address and Port
  http_port_min = 8802
  http_port_max = 8802

  communicator = "ssh"
  ssh_username = "${var.ssh_username}"

  # (Option 1) Add your Password here
  ssh_password = "${var.ssh_password}"
  # - or -
  # (Option 2) Add your Private SSH KEY file here
  # ssh_private_key_file = "~/.ssh/id_rsa"

  ssh_timeout = "${var.ssh_timeout}"
}

# Build Definition to create the VM Template
build {

  name    = "ubuntu-server-jammy"
  sources = ["proxmox-iso.ubuntu-server-jammy"]

  # Provisioning the VM Template for Cloud-Init Integration in Proxmox #1
  provisioner "shell" {
    inline = [
      "while [ ! -f /var/lib/cloud/instance/boot-finished ]; do echo 'Waiting for cloud-init...'; sleep 1; done",
      "sudo rm /etc/ssh/ssh_host_*",
      "sudo truncate -s 0 /etc/machine-id",
      "sudo apt -y autoremove --purge",
      "sudo apt -y clean",
      "sudo apt -y autoclean",
      "sudo cloud-init clean",
      "sudo rm -f /etc/cloud/cloud.cfg.d/subiquity-disable-cloudinit-networking.cfg",
      "sudo rm -f /etc/netplan/00-installer-config.yaml",
      "sudo sync"
    ]
  }

  # Provisioning the VM Template for Cloud-Init Integration in Proxmox #2
  provisioner "file" {
    source      = "files/99-pve.cfg"
    destination = "/tmp/99-pve.cfg"
  }

  # Provisioning the VM Template for Cloud-Init Integration in Proxmox #3
  provisioner "shell" {
    inline = ["sudo cp /tmp/99-pve.cfg /etc/cloud/cloud.cfg.d/99-pve.cfg"]
  }

}