iso_file = "local:iso/ubuntu-22.04.5-live-server-amd64.iso"
