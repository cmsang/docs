date
cd ubuntu-24.04-desktop-amd64
# load server variables
secrets_file="../../.secrets/packer.sh"
. "$secrets_file"
echo "Secrets file '$secrets_file' sourced successfully."

# create identical machine images
packer build -var-file=variables-ubuntu-24.04-desktop-amd64.pkr.hcl ubuntu-24.04-desktop-amd64.pkr.hcl

