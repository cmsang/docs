date
cd ubuntu-live-server-22.04
# load server variables
secrets_file="../../.secrets/packer.sh"
. "$secrets_file"
echo "Secrets file '$secrets_file' sourced successfully."

# create identical machine images
packer init ubuntu-live-server-22.04.pkr.hcl
packer build -var-file=variables-ubuntu-live-server-22.04.pkr.hcl ubuntu-live-server-22.04.pkr.hcl

