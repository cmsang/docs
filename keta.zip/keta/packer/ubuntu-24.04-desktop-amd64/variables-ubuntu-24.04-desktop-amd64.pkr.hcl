iso_file = "local:iso/ubuntu-24.04.1-desktop-amd64.iso"
iso_storage_pool = "local-lvm2"
