# cd ./terraform
# terraform init
# terraform plan
terraform apply -auto-approve

# terraform plan -out planfile
# terraform show -json planfile
