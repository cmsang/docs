proxmox_api_url = "https://14.232.56.120:8006/api2/json"
proxmox_api_token_id = "terraform-user@pve!provider"  # API Token ID
proxmox_api_token_secret = "a485bb49-0861-4780-9738-b361baa4e56e"
