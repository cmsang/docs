cd ./terraform

terraform destroy
