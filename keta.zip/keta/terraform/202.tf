resource "proxmox_vm_qemu" "pve02" {
  name        = "pve02"
  agent       = 1 # enable the QEMU Guest Agent
  target_node = "da02"
  qemu_os     = "other"   # default other
  bios        = "seabios" # default=ovmf
  tags        = "192.168.1.11;dawn"

  define_connection_info = false

  # -- only important for full clone
  vmid       = 202
  clone      = "packer-ubuntu-24-desktop-amd64"
  full_clone = true

  # -- boot process
  onboot           = true
  startup          = ""    # The startup and shutdown behaviour
  automatic_reboot = false # refuse auto-reboot when changing a setting

  cores   = 4
  sockets = 2
  cpu     = "host"
  memory  = 16384
  balloon = 1024

  network {
    bridge   = "vmbr1"
    model    = "virtio" # The 'virtio' model provides the best performance with very low CPU overhead
    firewall = true # enable the Proxmox firewall on this network device.
  }

  scsihw = "virtio-scsi-pci" # default virtio-scsi-pci

  # Cloud Init Settings
  ipconfig0  = "ip=192.168.1.11/24,gw=192.168.1.1"

  # Run a script after provisioning the VM
  provisioner "remote-exec" {
    inline = [
      "sudo apt update -y",
    ]

    connection {
      type     = "ssh"
      user     = "shk"
      password = "M5678"  # Alternatively use SSH keys if available
      host     = "192.168.1.11"
    }
  }
}
