export PKR_VAR_proxmox_api_url="https://14.232.56.120:8006/api2/json"
export PKR_VAR_proxmox_node="da02"
export PKR_VAR_proxmox_username="packer-user@pve!provider"
export PKR_VAR_proxmox_token="ff85b331-5b7c-4694-b521-42bfaf19adbc"

export PKR_VAR_ssh_username="keta"
# export PKR_VAR_ssh_password="\$6\$UoNhpuFyoLocyoim\$BTT.fSwd7Vk3zd./.IgpwS2923PkemrhEMZ.MdgVu2ZAvbV5YIjlSJjNUbOM7Db9dH8TnIyNhl6W8.5d4BFFu/"
export PKR_VAR_ssh_password="Keta#168"
export PKR_VAR_ssh_timeout="60m"

export PKR_VAR_host_ip=$(ipconfig | grep -i "IPv4" | awk -F": " '{print $2}' | tr -d '[:space:]')
echo $PKR_VAR_host_ip

# openssl passwd -6 'Keta#168'
# $6$CwKl2QxJ7obe.wdM$FUutXmm6XEjyAEa0dVBEfLjxOV81jOEGKIqdzk4zw67iNAZyeWOIBTloqxgiJH/5pJRlGtMHtRXVcLFHaoWvT0